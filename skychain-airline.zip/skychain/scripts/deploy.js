// Deploys SkyMiles, FlightTicket and SkyChainAirline, wires their roles,
// funds the compensation pool, publishes demo flights and writes
// frontend/deployment.json (addresses + ABIs) for the web app.
//
//   npx hardhat run scripts/deploy.js --network localhost

const fs = require("fs");
const path = require("path");
const { ethers, network } = require("hardhat");

const DAY = 24 * 60 * 60;

async function main() {
  const [admin, oracle, treasury] = await ethers.getSigners();
  console.log(`Network:   ${network.name}`);
  console.log(`Admin:     ${admin.address}  (airline + pauser)`);
  console.log(`Oracle:    ${oracle.address}`);
  console.log(`Treasury:  ${treasury.address}\n`);

  const miles = await ethers.deployContract("SkyMiles", [admin.address]);
  await miles.waitForDeployment();
  const tickets = await ethers.deployContract("FlightTicket", [admin.address]);
  await tickets.waitForDeployment();
  const airline = await ethers.deployContract("SkyChainAirline", [
    admin.address, treasury.address, await miles.getAddress(), await tickets.getAddress(),
  ]);
  await airline.waitForDeployment();
  const airlineAddr = await airline.getAddress();

  console.log(`SkyMiles         ${await miles.getAddress()}`);
  console.log(`FlightTicket     ${await tickets.getAddress()}`);
  console.log(`SkyChainAirline  ${airlineAddr}\n`);

  // --- wiring: the booking engine is the only minter / ticket issuer
  await (await miles.grantRole(await miles.MINTER_ROLE(), airlineAddr)).wait();
  await (await tickets.grantRole(await tickets.ISSUER_ROLE(), airlineAddr)).wait();
  await (await airline.grantRole(await airline.ORACLE_ROLE(), oracle.address)).wait();

  // --- airline bond for delay / cancellation compensation
  await (await airline.fundCompensationPool({ value: ethers.parseEther("20") })).wait();

  // --- welcome miles for the admin account so award booking can be tried
  await (await miles.grantRole(await miles.MINTER_ROLE(), admin.address)).wait();
  await (await miles.mint(admin.address, ethers.parseEther("50000"), ethers.encodeBytes32String("WELCOME"))).wait();
  await (await miles.revokeRole(await miles.MINTER_ROLE(), admin.address)).wait();

  // --- demo flights
  const now = (await ethers.provider.getBlock("latest")).timestamp;
  const flights = [
    ["SK101", "TUN", "CDG", now + 10 * DAY, 120, "0.25", "20000", "1500"],
    ["SK214", "TUN", "FCO", now + 4 * DAY, 90, "0.18", "15000", "900"],
    ["SK330", "TUN", "IST", now + 3 * DAY, 150, "0.22", "18000", "1200"],
    ["SK405", "TUN", "DXB", now + 14 * DAY, 200, "0.60", "45000", "3800"],
  ];
  for (const [code, from, to, dep, cap, price, milesPrice, reward] of flights) {
    await (await airline.createFlight(
      code, from, to, dep, cap,
      ethers.parseEther(price), ethers.parseEther(milesPrice), ethers.parseEther(reward)
    )).wait();
    console.log(`Flight ${code} ${from}→${to} published`);
  }

  // --- export for the frontend
  const artifact = (name) => require(path.join(__dirname, "..", "artifacts", "contracts", `${name}.sol`, `${name}.json`));
  const out = {
    chainId: Number(network.config.chainId ?? 31337),
    rpcUrl: "http://127.0.0.1:8545",
    accounts: { admin: admin.address, oracle: oracle.address, treasury: treasury.address },
    contracts: {
      SkyChainAirline: { address: airlineAddr, abi: artifact("SkyChainAirline").abi },
      SkyMiles: { address: await miles.getAddress(), abi: artifact("SkyMiles").abi },
      FlightTicket: { address: await tickets.getAddress(), abi: artifact("FlightTicket").abi },
    },
  };
  const file = path.join(__dirname, "..", "frontend", "deployment.json");
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log(`\nWrote ${path.relative(process.cwd(), file)}`);
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});

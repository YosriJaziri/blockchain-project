// Plays a full flight lifecycle on the local node, with time travel, and
// prints what every party receives. Run AFTER deploy.js:
//
//   npx hardhat run scripts/simulate.js --network localhost

const { ethers, network } = require("hardhat");
const deployment = require("../frontend/deployment.json");

const fmt = (wei) => ethers.formatEther(wei);
async function travelTo(ts) {
  await network.provider.send("evm_setNextBlockTimestamp", [Number(ts)]);
  await network.provider.send("evm_mine");
}

async function main() {
  const [admin, oracle, treasury, alice, bob, carol] = await ethers.getSigners();
  const c = deployment.contracts;
  const airline = await ethers.getContractAt(c.SkyChainAirline.abi, c.SkyChainAirline.address);
  const miles = await ethers.getContractAt(c.SkyMiles.abi, c.SkyMiles.address);
  const tickets = await ethers.getContractAt(c.FlightTicket.abi, c.FlightTicket.address);

  const now = (await ethers.provider.getBlock("latest")).timestamp;
  const dep = now + 6 * 24 * 3600;
  const tx = await airline.createFlight("SK999", "TUN", "MAD", dep, 10, ethers.parseEther("0.3"), 0, ethers.parseEther("1000"));
  const flightId = (await tx.wait()).logs.map((l) => airline.interface.parseLog(l)).find((e) => e?.name === "FlightCreated").args.flightId;
  console.log(`1. Flight SK999 TUN→MAD created (id ${flightId})`);

  const price = ethers.parseEther("0.3");
  const ids = [];
  for (const p of [alice, bob, carol]) {
    const r = await (await airline.connect(p).bookFlight(flightId, { value: price })).wait();
    ids.push(r.logs.map((l) => { try { return airline.interface.parseLog(l); } catch { return null; } }).find((e) => e?.name === "TicketBooked").args.ticketId);
  }
  console.log(`2. Alice, Bob and Carol booked tickets ${ids.join(", ")}`);

  await (await tickets.connect(carol).transferFrom(carol.address, bob.address, ids[2])).wait();
  console.log(`3. Carol resold ticket ${ids[2]} to Bob (NFT transfer)`);

  await travelTo(dep - 3 * 24 * 3600);
  await (await airline.connect(bob).cancelBooking(ids[2])).wait();
  console.log(`4. Bob cancels the resold ticket 3 days out → 50% refund: ${fmt(await airline.pendingWithdrawals(bob.address))} ETH pending`);

  await travelTo(dep - 20 * 3600);
  await (await airline.connect(alice).checkIn(ids[0])).wait();
  await (await airline.connect(bob).checkIn(ids[1])).wait();
  console.log(`5. Alice and Bob checked in — tickets locked: ${await tickets.locked(ids[0])}`);

  await (await airline.connect(oracle).reportDelay(flightId, 210)).wait();
  console.log("6. Oracle: flight delayed 3h30");
  await (await airline.connect(oracle).reportDeparture(flightId)).wait();
  await (await airline.connect(oracle).reportLanding(flightId)).wait();
  console.log("7. Oracle: departed, landed");

  for (const [p, id, name] of [[alice, ids[0], "Alice"], [bob, ids[1], "Bob"]]) {
    await (await airline.connect(p).claimDelayCompensation(id)).wait();
    await (await airline.connect(p).claimMiles(id)).wait();
    console.log(`8. ${name}: ${fmt(await airline.pendingWithdrawals(p.address))} ETH pending, ${fmt(await miles.balanceOf(p.address))} MILES`);
  }

  await (await airline.settleFlight(flightId)).wait();
  console.log(`9. Settled — treasury has ${fmt(await airline.pendingWithdrawals(treasury.address))} ETH to withdraw`);
  console.log(`   Compensation pool left: ${fmt(await airline.compensationPool())} ETH`);
}

main().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});

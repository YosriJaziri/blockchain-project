require("@nomicfoundation/hardhat-toolbox");

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.28",
    settings: {
      optimizer: { enabled: true, runs: 200 },
      viaIR: true, // long string.concat in the on-chain SVG needs the IR pipeline
    },
  },
  networks: {
    localhost: { url: "http://127.0.0.1:8545", chainId: 31337 },
  },
  gasReporter: { enabled: process.env.REPORT_GAS === "true" },
};

const { expect } = require("chai");
const { ethers } = require("hardhat");
const { loadFixture, time } = require("@nomicfoundation/hardhat-network-helpers");

const DAY = 24 * 60 * 60;
const HOUR = 60 * 60;
const PRICE = ethers.parseEther("0.5");
const MILES_PRICE = ethers.parseEther("20000");
const MILES_REWARD = ethers.parseEther("1500");

async function deployFixture() {
  const [admin, treasury, oracle, alice, bob, mallory] = await ethers.getSigners();

  const miles = await ethers.deployContract("SkyMiles", [admin.address]);
  const tickets = await ethers.deployContract("FlightTicket", [admin.address]);
  const airline = await ethers.deployContract("SkyChainAirline", [
    admin.address, treasury.address, await miles.getAddress(), await tickets.getAddress(),
  ]);
  const airlineAddr = await airline.getAddress();

  await miles.grantRole(await miles.MINTER_ROLE(), airlineAddr);
  await tickets.grantRole(await tickets.ISSUER_ROLE(), airlineAddr);
  await airline.grantRole(await airline.ORACLE_ROLE(), oracle.address);
  await airline.fundCompensationPool({ value: ethers.parseEther("10") });

  const departure = (await time.latest()) + 10 * DAY;
  await airline.createFlight("SK101", "TUN", "CDG", departure, 3, PRICE, MILES_PRICE, MILES_REWARD);

  return { miles, tickets, airline, admin, treasury, oracle, alice, bob, mallory, departure, flightId: 1n };
}

async function bookedFixture() {
  const ctx = await deployFixture();
  await ctx.airline.connect(ctx.alice).bookFlight(ctx.flightId, { value: PRICE });
  return { ...ctx, ticketId: 1n };
}

async function checkedInFixture() {
  const ctx = await bookedFixture();
  await time.increaseTo(ctx.departure - 24 * HOUR);
  await ctx.airline.connect(ctx.alice).checkIn(ctx.ticketId);
  return ctx;
}

describe("SkyChainAirline", function () {
  describe("Flights", function () {
    it("stores a scheduled flight", async function () {
      const { airline, departure } = await loadFixture(deployFixture);
      const f = await airline.getFlight(1);
      expect(f.code).to.equal("SK101");
      expect(f.departure).to.equal(departure);
      expect(f.status).to.equal(1); // Scheduled
    });

    it("only the airline can create flights", async function () {
      const { airline, mallory } = await loadFixture(deployFixture);
      const dep = (await time.latest()) + 10 * DAY;
      await expect(airline.connect(mallory).createFlight("X", "A", "B", dep, 1, 1, 0, 0))
        .to.be.revertedWithCustomError(airline, "AccessControlUnauthorizedAccount");
    });

    it("rejects flights departing too soon", async function () {
      const { airline } = await loadFixture(deployFixture);
      const dep = (await time.latest()) + HOUR;
      await expect(airline.createFlight("X", "A", "B", dep, 1, 1, 0, 0))
        .to.be.revertedWithCustomError(airline, "InvalidParameters");
    });
  });

  describe("Booking", function () {
    it("mints an NFT ticket and holds the fare in escrow", async function () {
      const { airline, tickets, alice, flightId } = await loadFixture(deployFixture);
      await expect(airline.connect(alice).bookFlight(flightId, { value: PRICE }))
        .to.emit(airline, "TicketBooked").withArgs(1, flightId, alice.address, 1, PRICE, 0);
      expect(await tickets.ownerOf(1)).to.equal(alice.address);
      expect((await airline.getFlight(flightId)).escrow).to.equal(PRICE);
    });

    it("rejects a wrong payment", async function () {
      const { airline, alice, flightId } = await loadFixture(deployFixture);
      await expect(airline.connect(alice).bookFlight(flightId, { value: 1 }))
        .to.be.revertedWithCustomError(airline, "WrongPayment");
    });

    it("stops selling when the flight is full", async function () {
      const { airline, alice, bob, flightId } = await loadFixture(deployFixture);
      for (let i = 0; i < 3; i++) await airline.connect(alice).bookFlight(flightId, { value: PRICE });
      await expect(airline.connect(bob).bookFlight(flightId, { value: PRICE }))
        .to.be.revertedWithCustomError(airline, "SoldOut");
    });

    it("produces on-chain JSON metadata with an SVG boarding pass", async function () {
      const { tickets, ticketId } = await loadFixture(bookedFixture);
      const uri = await tickets.tokenURI(ticketId);
      const json = JSON.parse(Buffer.from(uri.split(",")[1], "base64").toString());
      expect(json.name).to.equal("SK101 seat 1");
      expect(json.image).to.match(/^data:image\/svg\+xml;base64,/);
    });

    it("lets a passenger book an award seat with miles (approve + burnFrom)", async function () {
      const { airline, miles, admin, alice, flightId } = await loadFixture(deployFixture);
      await miles.grantRole(await miles.MINTER_ROLE(), admin.address);
      await miles.mint(alice.address, MILES_PRICE, ethers.encodeBytes32String("PROMO"));
      await miles.connect(alice).approve(await airline.getAddress(), MILES_PRICE);

      await airline.connect(alice).bookWithMiles(flightId);
      expect(await miles.balanceOf(alice.address)).to.equal(0);
      expect((await airline.getBooking(1)).paidMiles).to.equal(MILES_PRICE);
    });

    it("pausing blocks new bookings", async function () {
      const { airline, alice, flightId } = await loadFixture(deployFixture);
      await airline.pause();
      await expect(airline.connect(alice).bookFlight(flightId, { value: PRICE }))
        .to.be.revertedWithCustomError(airline, "EnforcedPause");
    });
  });

  describe("Resale and check-in", function () {
    it("allows resale before check-in; the new owner controls the booking", async function () {
      const { airline, tickets, alice, bob, ticketId } = await loadFixture(bookedFixture);
      await tickets.connect(alice).transferFrom(alice.address, bob.address, ticketId);
      await expect(airline.connect(alice).cancelBooking(ticketId))
        .to.be.revertedWithCustomError(airline, "NotTicketOwner");
      await airline.connect(bob).cancelBooking(ticketId);
      expect(await airline.pendingWithdrawals(bob.address)).to.equal(PRICE);
    });

    it("refuses check-in before the 48h window", async function () {
      const { airline, alice, ticketId } = await loadFixture(bookedFixture);
      await expect(airline.connect(alice).checkIn(ticketId))
        .to.be.revertedWithCustomError(airline, "CheckInNotOpen");
    });

    it("locks the ticket at check-in (soulbound boarding pass)", async function () {
      const { tickets, alice, bob, ticketId } = await loadFixture(checkedInFixture);
      expect(await tickets.locked(ticketId)).to.equal(true);
      await expect(tickets.connect(alice).transferFrom(alice.address, bob.address, ticketId))
        .to.be.revertedWithCustomError(tickets, "TicketLocked");
    });
  });

  describe("Passenger cancellation policy", function () {
    it("refunds 100% more than 7 days out", async function () {
      const { airline, alice, ticketId } = await loadFixture(bookedFixture);
      await airline.connect(alice).cancelBooking(ticketId);
      expect(await airline.pendingWithdrawals(alice.address)).to.equal(PRICE);
    });

    it("refunds 50% between 7 days and 48h; penalty goes to the treasury", async function () {
      const { airline, alice, treasury, ticketId, departure } = await loadFixture(bookedFixture);
      await time.increaseTo(departure - 3 * DAY);
      await airline.connect(alice).cancelBooking(ticketId);
      expect(await airline.pendingWithdrawals(alice.address)).to.equal(PRICE / 2n);
      expect(await airline.pendingWithdrawals(treasury.address)).to.equal(PRICE / 2n);
    });

    it("refunds nothing inside 48h", async function () {
      const { airline, alice, ticketId, departure } = await loadFixture(bookedFixture);
      await time.increaseTo(departure - 24 * HOUR);
      const [bps] = await airline.refundQuote(ticketId);
      expect(bps).to.equal(0);
    });

    it("frees the seat and burns the ticket", async function () {
      const { airline, tickets, alice, ticketId, flightId } = await loadFixture(bookedFixture);
      await airline.connect(alice).cancelBooking(ticketId);
      expect((await airline.getFlight(flightId)).sold).to.equal(0);
      await expect(tickets.ownerOf(ticketId)).to.be.revertedWithCustomError(tickets, "ERC721NonexistentToken");
    });
  });

  describe("Airline cancellation", function () {
    it("refunds the fare plus 25% compensation", async function () {
      const { airline, alice, ticketId, flightId } = await loadFixture(bookedFixture);
      await airline.cancelFlight(flightId);
      await airline.connect(alice).claimCancellationRefund(ticketId);
      expect(await airline.pendingWithdrawals(alice.address)).to.equal(PRICE + PRICE / 4n);
    });

    it("pays out through withdraw()", async function () {
      const { airline, alice, ticketId, flightId } = await loadFixture(bookedFixture);
      await airline.cancelFlight(flightId);
      await airline.connect(alice).claimCancellationRefund(ticketId);
      const owed = PRICE + PRICE / 4n;
      await expect(airline.connect(alice).withdraw()).to.changeEtherBalance(alice, owed);
      await expect(airline.connect(alice).withdraw()).to.be.revertedWithCustomError(airline, "NothingToWithdraw");
    });
  });

  describe("Oracle, delays and loyalty", function () {
    it("only the oracle can report flight status", async function () {
      const { airline, mallory, flightId } = await loadFixture(deployFixture);
      await expect(airline.connect(mallory).reportDelay(flightId, 200))
        .to.be.revertedWithCustomError(airline, "AccessControlUnauthorizedAccount");
    });

    it("a delay moves the check-in window", async function () {
      const { airline, oracle, alice, ticketId, flightId, departure } = await loadFixture(bookedFixture);
      await airline.connect(oracle).reportDelay(flightId, 240);
      expect(await airline.effectiveDeparture(flightId)).to.equal(BigInt(departure) + 240n * 60n);
      await time.increaseTo(departure - 30 * 60); // 30 min before scheduled, 4h30 before real
      await expect(airline.connect(alice).checkIn(ticketId)).to.not.be.reverted;
    });

    it("pays 50% compensation and bonus miles for a 3h+ delay", async function () {
      const { airline, miles, oracle, alice, ticketId, flightId } = await loadFixture(checkedInFixture);
      await airline.connect(oracle).reportDelay(flightId, 200);
      await airline.connect(oracle).reportDeparture(flightId);
      await airline.connect(alice).claimDelayCompensation(ticketId);
      expect(await airline.pendingWithdrawals(alice.address)).to.equal(PRICE / 2n);
      expect(await miles.balanceOf(alice.address)).to.equal(MILES_REWARD);
      await expect(airline.connect(alice).claimDelayCompensation(ticketId))
        .to.be.revertedWithCustomError(airline, "AlreadyClaimed");
    });

    it("no compensation under the threshold", async function () {
      const { airline, oracle, alice, ticketId, flightId } = await loadFixture(checkedInFixture);
      await airline.connect(oracle).reportDelay(flightId, 90);
      await airline.connect(oracle).reportDeparture(flightId);
      await expect(airline.connect(alice).claimDelayCompensation(ticketId))
        .to.be.revertedWithCustomError(airline, "NotEligible");
    });

    it("awards miles after landing, once", async function () {
      const { airline, miles, oracle, alice, ticketId, flightId } = await loadFixture(checkedInFixture);
      await airline.connect(oracle).reportDeparture(flightId);
      await airline.connect(oracle).reportLanding(flightId);
      await airline.connect(alice).claimMiles(ticketId);
      expect(await miles.balanceOf(alice.address)).to.equal(MILES_REWARD);
      await expect(airline.connect(alice).claimMiles(ticketId))
        .to.be.revertedWithCustomError(airline, "AlreadyClaimed");
    });

    it("no-shows earn no miles", async function () {
      const { airline, oracle, alice, ticketId, flightId } = await loadFixture(bookedFixture);
      await airline.connect(oracle).reportDeparture(flightId);
      await airline.connect(oracle).reportLanding(flightId);
      await expect(airline.connect(alice).claimMiles(ticketId))
        .to.be.revertedWithCustomError(airline, "NotEligible");
    });
  });

  describe("Settlement", function () {
    it("moves the escrow to the treasury after landing", async function () {
      const { airline, oracle, treasury, flightId } = await loadFixture(checkedInFixture);
      await airline.connect(oracle).reportDeparture(flightId);
      await airline.connect(oracle).reportLanding(flightId);
      await expect(airline.settleFlight(flightId)).to.emit(airline, "FlightSettled").withArgs(flightId, PRICE);
      await expect(airline.connect(treasury).withdraw()).to.changeEtherBalance(treasury, PRICE);
    });

    it("cannot settle before landing", async function () {
      const { airline, flightId } = await loadFixture(bookedFixture);
      await expect(airline.settleFlight(flightId)).to.be.revertedWithCustomError(airline, "WrongStatus");
    });
  });
});

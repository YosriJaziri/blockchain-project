// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {ERC20} from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import {ERC20Burnable} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol";
import {ERC20Permit} from "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";

/// @title SkyMiles — the airline loyalty token (ERC-20)
/// @notice Earned by flying, spent on award tickets. Only contracts holding
///         MINTER_ROLE (the booking engine) can create miles. Redemption burns
///         miles through the standard allowance flow (approve + burnFrom), so
///         nobody can take a passenger's miles without their consent.
/// @dev    ERC20Permit lets a passenger approve with an off-chain EIP-712
///         signature instead of a separate approve() transaction.
contract SkyMiles is ERC20, ERC20Burnable, ERC20Permit, AccessControl {
    bytes32 public constant MINTER_ROLE = keccak256("MINTER_ROLE");

    event MilesMinted(address indexed to, uint256 amount, bytes32 indexed reason);

    constructor(address admin) ERC20("SkyMiles", "MILES") ERC20Permit("SkyMiles") {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    /// @param reason short tag stored in the event log, e.g. "FLIGHT", "DELAY_BONUS", "REFUND"
    function mint(address to, uint256 amount, bytes32 reason) external onlyRole(MINTER_ROLE) {
        _mint(to, amount);
        emit MilesMinted(to, amount, reason);
    }
}

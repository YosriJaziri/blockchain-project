// SPDX-License-Identifier: MIT
pragma solidity ^0.8.28;

import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {ERC721Enumerable} from "@openzeppelin/contracts/token/ERC721/extensions/ERC721Enumerable.sol";
import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
import {Strings} from "@openzeppelin/contracts/utils/Strings.sol";
import {Base64} from "@openzeppelin/contracts/utils/Base64.sol";

/// @title FlightTicket — every seat is an NFT (ERC-721)
/// @notice Tickets can be resold peer-to-peer until check-in. At check-in the
///         booking engine locks the token, turning it into a non-transferable
///         boarding pass bound to the passenger who checked in.
/// @dev    Metadata and the boarding-pass image are generated fully on-chain
///         (JSON + SVG, Base64-encoded) — no IPFS or server needed.
contract FlightTicket is ERC721, ERC721Enumerable, AccessControl {
    using Strings for uint256;

    bytes32 public constant ISSUER_ROLE = keccak256("ISSUER_ROLE");

    struct TicketData {
        uint256 flightId;
        string flightCode;
        string origin;
        string destination;
        uint64 departure;
        uint32 seat;
        bool awardTicket; // paid with miles
    }

    mapping(uint256 => TicketData) private _tickets;
    mapping(uint256 => bool) public locked;
    uint256 private _nextId = 1;

    error TicketLocked(uint256 tokenId);

    event TicketLockedForBoarding(uint256 indexed tokenId);

    constructor(address admin) ERC721("SkyChain Flight Ticket", "SKYT") {
        _grantRole(DEFAULT_ADMIN_ROLE, admin);
    }

    // ------------------------------------------------------------ issuer only

    function issue(address to, TicketData calldata data) external onlyRole(ISSUER_ROLE) returns (uint256 tokenId) {
        tokenId = _nextId++;
        _tickets[tokenId] = data;
        _safeMint(to, tokenId);
    }

    function lock(uint256 tokenId) external onlyRole(ISSUER_ROLE) {
        _requireOwned(tokenId);
        locked[tokenId] = true;
        emit TicketLockedForBoarding(tokenId);
    }

    function burn(uint256 tokenId) external onlyRole(ISSUER_ROLE) {
        _burn(tokenId);
        delete _tickets[tokenId];
        delete locked[tokenId];
    }

    // ------------------------------------------------------------ views

    function ticketData(uint256 tokenId) external view returns (TicketData memory) {
        _requireOwned(tokenId);
        return _tickets[tokenId];
    }

    function tokenURI(uint256 tokenId) public view override returns (string memory) {
        _requireOwned(tokenId);
        TicketData memory t = _tickets[tokenId];
        string memory status = locked[tokenId] ? "Checked in" : "Booked";
        string memory seat = uint256(t.seat).toString();

        string memory attributes = string.concat(
            '[{"trait_type":"Flight","value":"', t.flightCode, '"},',
            '{"trait_type":"Route","value":"', t.origin, "-", t.destination, '"},',
            '{"trait_type":"Seat","value":', seat, "},",
            '{"display_type":"date","trait_type":"Departure","value":', uint256(t.departure).toString(), "},",
            '{"trait_type":"Fare","value":"', t.awardTicket ? "Award (miles)" : "Cash", '"},',
            '{"trait_type":"Status","value":"', status, '"}]'
        );

        string memory json = string.concat(
            '{"name":"', t.flightCode, " seat ", seat,
            '","description":"SkyChain flight ticket ', t.origin, " to ", t.destination,
            '","image":"data:image/svg+xml;base64,', Base64.encode(bytes(_svg(t, seat, status))),
            '","attributes":', attributes, "}"
        );
        return string.concat("data:application/json;base64,", Base64.encode(bytes(json)));
    }

    function _svg(TicketData memory t, string memory seat, string memory status) private pure returns (string memory) {
        return string.concat(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 200">',
            '<rect width="400" height="200" rx="14" fill="#0f2a44"/>',
            '<rect x="290" width="110" height="200" rx="14" fill="#1d8a8a"/>',
            '<line x1="290" y1="12" x2="290" y2="188" stroke="#fff" stroke-dasharray="4 6"/>',
            '<text x="24" y="44" fill="#9fc6d6" font-family="sans-serif" font-size="14">', t.flightCode, "</text>",
            '<text x="24" y="104" fill="#fff" font-family="sans-serif" font-size="40" font-weight="700">',
            t.origin, " / ", t.destination, "</text>",
            '<text x="24" y="160" fill="#9fc6d6" font-family="sans-serif" font-size="13">', status, "</text>",
            '<text x="345" y="90" fill="#fff" font-family="sans-serif" font-size="13" text-anchor="middle">Seat</text>',
            '<text x="345" y="130" fill="#fff" font-family="sans-serif" font-size="36" font-weight="700" text-anchor="middle">',
            seat, "</text></svg>"
        );
    }

    // ------------------------------------------------------------ transfer rules

    /// @dev Blocks wallet-to-wallet transfers of locked (checked-in) tickets.
    ///      Mint (from == 0) and burn (to == 0) always pass.
    function _update(address to, uint256 tokenId, address auth)
        internal
        override(ERC721, ERC721Enumerable)
        returns (address)
    {
        address from = _ownerOf(tokenId);
        if (from != address(0) && to != address(0) && locked[tokenId]) revert TicketLocked(tokenId);
        return super._update(to, tokenId, auth);
    }

    function _increaseBalance(address account, uint128 value) internal override(ERC721, ERC721Enumerable) {
        super._increaseBalance(account, value);
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(ERC721, ERC721Enumerable, AccessControl)
        returns (bool)
    {
        return super.supportsInterface(interfaceId);
    }
}
